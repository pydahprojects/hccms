import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import Layout from './components/Layout';
import AdminDashboard from './pages/AdminDashboard';
import StudentDashboard from './pages/StudentDashboard';
import RaiseComplaint from './components/Students/RaiseComplaint';
import TrackComplaint from './components/Students/TrackComplaint';

function App() {
  return (
    <Router>
      <div className="bg-gray-50">
        <Layout>
          <Routes>
            {/* Redirect root to student dashboard */}
            <Route path="/" element={<Navigate to="/student" replace />} />
            
            {/* Student Dashboard Route */}
            <Route path="/student" element={<StudentDashboard />} />
            
            {/* Admin Dashboard Route */}
            <Route path="/admin" element={<AdminDashboard />} />
            
            {/* Raise Complaint Route */}
            <Route path="/raise-complaint" element={<RaiseComplaint />} />
            
            {/* Track Complaint Route */}
            <Route path="/track-complaint" element={<TrackComplaint />} />
            
            {/* Catch all route - redirect to student dashboard */}
            <Route path="*" element={<Navigate to="/student" replace />} />
          </Routes>
        </Layout>
      </div>
    </Router>
  );
}

export default App;