import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { getFirestore, collection, query, where, getDocs, orderBy, limit, doc, updateDoc, deleteDoc } from 'firebase/firestore';
import { initializeApp } from 'firebase/app';
import ComplaintDetails from './ComplaintDetails';
import { Trash2, AlertCircle } from 'lucide-react';

// Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyCBBI_wnLhnjLer5fj_GX3g0O4XWf09wj8",
  authDomain: "hccms-60949.firebaseapp.com",
  projectId: "hccms-60949",
  storageBucket: "hccms-60949.firebasestorage.app",
  messagingSenderId: "1068287700605",
  appId: "1:1068287700605:web:a82b45ae0741c4076d4b14"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const db = getFirestore(app);

interface Complaint {
  id: string;
  token: string;
  name: string;
  studentId: string;
  category: string;
  description: string;
  status: string;
  createdAt: any;
  locationType: string;
  locationDetail: string;
  attachmentUrls?: string[];
  solutionStatus?: 'pending_approval' | 'approved' | 'declined';
  solutionNote?: string;
  solvedAt?: any;
  declineFeedback?: string;
}

const TrackComplaint = () => {
  const [trackingToken, setTrackingToken] = useState('');
  const [searchError, setSearchError] = useState<string | null>(null);
  const [recentComplaints, setRecentComplaints] = useState<Complaint[]>([]);
  const [loading, setLoading] = useState(false);
  const [selectedComplaint, setSelectedComplaint] = useState<Complaint | null>(null);
  const [showDetails, setShowDetails] = useState(false);
  const [showApprovalModal, setShowApprovalModal] = useState(false);
  const [complaintForApproval, setComplaintForApproval] = useState<Complaint | null>(null);
  const [showFeedbackModal, setShowFeedbackModal] = useState(false);
  const [declineFeedback, setDeclineFeedback] = useState('');
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [complaintToDelete, setComplaintToDelete] = useState<Complaint | null>(null);
  const [isDeleting, setIsDeleting] = useState(false);

  // Fetch recent solved complaints
  useEffect(() => {
    const fetchRecentSolvedComplaints = async () => {
      try {
        const q = query(
          collection(db, 'complaints'),
          where('status', '==', 'solved'),
          where('solutionStatus', '==', 'approved'),
          orderBy('createdAt', 'desc'),
          limit(5)
        );
        
        const querySnapshot = await getDocs(q);
        const complaints: Complaint[] = [];
        querySnapshot.forEach((doc) => {
          complaints.push({ id: doc.id, ...doc.data() } as Complaint);
        });
        
        console.log('Fetched solved complaints:', complaints); // Debug log
        setRecentComplaints(complaints);
      } catch (error) {
        console.error('Error fetching recent complaints:', error);
      }
    };

    fetchRecentSolvedComplaints();
  }, []);

  // Track complaint by token
  const handleTrackComplaint = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setSearchError(null);

    try {
      const q = query(
        collection(db, 'complaints'),
        where('token', '==', trackingToken)
      );
      
      const querySnapshot = await getDocs(q);
      
      if (querySnapshot.empty) {
        setSearchError('No complaint found with this tracking token');
        return;
      }

      const complaintData = { 
        id: querySnapshot.docs[0].id, 
        ...querySnapshot.docs[0].data() 
      } as Complaint;
      
      setSelectedComplaint(complaintData);
      setShowDetails(true);
    } catch (error) {
      console.error('Error tracking complaint:', error);
      setSearchError('Failed to track complaint. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const handleSolutionResponse = async (approved: boolean) => {
    if (!selectedComplaint) return;

    if (!approved) {
      setShowFeedbackModal(true);
      return;
    }

    try {
      await updateDoc(doc(db, 'complaints', selectedComplaint.id), {
        solutionStatus: 'approved',
        updatedAt: new Date()
      });

      setSelectedComplaint({
        ...selectedComplaint,
        solutionStatus: 'approved' as const
      });

      alert('Solution approved successfully!');
    } catch (error) {
      console.error('Error updating solution status:', error);
      alert('Failed to update solution status. Please try again.');
    }
  };

  const handleDeclineWithFeedback = async () => {
    if (!selectedComplaint || !declineFeedback.trim()) {
      alert('Please provide feedback before declining');
      return;
    }

    try {
      await updateDoc(doc(db, 'complaints', selectedComplaint.id), {
        status: 'in-progress',
        solutionStatus: 'declined',
        declineFeedback: declineFeedback,
        updatedAt: new Date()
      });

      setSelectedComplaint({
        ...selectedComplaint,
        status: 'in-progress',
        solutionStatus: 'declined',
        declineFeedback: declineFeedback
      });

      setShowFeedbackModal(false);
      setDeclineFeedback('');
      alert('Solution declined and feedback sent successfully!');
    } catch (error) {
      console.error('Error updating solution status:', error);
      alert('Failed to update solution status. Please try again.');
    }
  };

  const handleDeleteClick = (complaint: Complaint) => {
    setComplaintToDelete(complaint);
    setShowDeleteModal(true);
  };

  const handleDeleteConfirm = async () => {
    if (!complaintToDelete) return;

    setIsDeleting(true);
    try {
      await deleteDoc(doc(db, 'complaints', complaintToDelete.id));
      
      setRecentComplaints(prev => prev.filter(c => c.id !== complaintToDelete.id));
      
      if (selectedComplaint?.id === complaintToDelete.id) {
        setSelectedComplaint(null);
        setShowDetails(false);
      }

      setShowDeleteModal(false);
      alert('Complaint deleted successfully!');
    } catch (error) {
      console.error('Error deleting complaint:', error);
      alert('Failed to delete complaint. Please try again.');
    } finally {
      setIsDeleting(false);
      setComplaintToDelete(null);
    }
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="max-w-4xl mx-auto">
        <div className="overflow-hidden whitespace-nowrap mb-8">
          <motion.h1 
            className="text-3xl font-bold text-[#F27528] inline-block"
            animate={{
              x: ["100%", "-100%"]
            }}
            transition={{
              duration: 15,
              repeat: Infinity,
              ease: "linear"
            }}
          >
            Track Your Complaint
          </motion.h1>
        </div>
        
        {!showDetails ? (
          <div className="bg-white rounded-lg shadow-md p-6">
            {/* Search Form */}
            <form onSubmit={handleTrackComplaint} className="mb-8">
              <div className="flex flex-col md:flex-row gap-4">
                <input
                  type="text"
                  value={trackingToken}
                  onChange={(e) => setTrackingToken(e.target.value)}
                  placeholder="Enter your complaint token (e.g., HCCMS-123456-789)"
                  className="flex-1 p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#F27528] focus:border-transparent"
                  required
                />
                <button
                  type="submit"
                  disabled={loading}
                  className={`px-6 py-3 rounded-lg font-semibold ${
                    loading
                      ? 'bg-gray-400 cursor-not-allowed'
                      : 'bg-[#F27528] hover:bg-[#d65a0f] text-white'
                  }`}
                >
                  {loading ? 'Tracking...' : 'Track'}
                </button>
              </div>
              {searchError && (
                <p className="mt-2 text-red-600 text-sm">{searchError}</p>
              )}
            </form>

            {/* Recent Solved Complaints */}
            <div>
              <h2 className="text-xl font-semibold text-gray-800 mb-4">Recently Solved Complaints</h2>
              
              {recentComplaints.length === 0 ? (
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="text-center py-8"
                >
                  <div className="mb-4">
                    <svg 
                      className="mx-auto h-12 w-12 text-gray-400"
                      fill="none" 
                      viewBox="0 0 24 24" 
                      stroke="currentColor"
                    >
                      <path 
                        strokeLinecap="round" 
                        strokeLinejoin="round" 
                        strokeWidth={2} 
                        d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" 
                      />
                    </svg>
                  </div>
                  <h3 className="text-lg font-medium text-gray-900 mb-1">
                    No Solved Complaints Yet
                  </h3>
                  <p className="text-gray-500">
                    There are no solved complaints to display at the moment.
                  </p>
                </motion.div>
              ) : (
                <div className="space-y-4">
                  {recentComplaints.map((complaint) => (
                    <div key={complaint.id} className="border border-gray-200 rounded-lg p-4 hover:shadow-md transition-shadow">
                      <div className="flex justify-between items-start mb-2">
                        <div>
                          <h3 className="font-semibold text-gray-800">{complaint.token}</h3>
                          <p className="text-sm text-gray-600">Category: {complaint.category}</p>
                        </div>
                        <span className="px-3 py-1 text-sm rounded-full bg-green-100 text-green-800">
                          Solved
                        </span>
                      </div>
                      <p className="text-gray-700 mb-2">{complaint.description?.substring(0, 100)}...</p>
                      <div className="flex justify-between items-center text-sm text-gray-500">
                        <span>
                          {complaint.createdAt?.toDate().toLocaleDateString()}
                        </span>
                        <button
                          onClick={() => {
                            setSelectedComplaint(complaint);
                            setShowDetails(true);
                          }}
                          className="text-[#F27528] hover:underline"
                        >
                          View Details
                        </button>
                      </div>
                      <div className="mt-2 flex justify-end">
                        <button
                          onClick={() => handleDeleteClick(complaint)}
                          className="flex items-center gap-2 text-sm text-red-500 hover:text-red-600"
                        >
                          <Trash2 className="w-4 h-4" />
                          Delete
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        ) : (
          <>
            <ComplaintDetails 
              complaint={selectedComplaint!} 
              onClose={() => {
                setShowDetails(false);
                setSelectedComplaint(null);
              }}
            />
            {selectedComplaint?.status === 'solved' && 
             selectedComplaint?.solutionStatus === 'pending_approval' && (
              <div className="mt-6 bg-white rounded-lg shadow-md p-6">
                <h3 className="text-xl font-bold text-gray-800 mb-4">Solution Approval</h3>
                <p className="text-gray-600 mb-4">
                  The staff has marked this complaint as resolved. Please review the solution and approve or decline.
                </p>
                <div className="bg-gray-50 p-4 rounded-lg mb-4">
                  <h4 className="font-medium text-gray-700 mb-2">Solution Note:</h4>
                  <p className="text-gray-600">{selectedComplaint.solutionNote}</p>
                </div>
                <div className="flex justify-end gap-4">
                  <button
                    onClick={() => handleSolutionResponse(false)}
                    className="px-4 py-2 text-sm font-medium text-red-600 border border-red-600 rounded-md hover:bg-red-50 transition-colors"
                  >
                    Decline Solution
                  </button>
                  <button
                    onClick={() => handleSolutionResponse(true)}
                    className="px-4 py-2 text-sm font-medium text-white bg-green-600 rounded-md hover:bg-green-700 transition-colors"
                  >
                    Approve Solution
                  </button>
                </div>
              </div>
            )}
          </>
        )}
      </div>

      {/* Feedback Modal */}
      {showFeedbackModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="bg-white rounded-lg p-6 max-w-md w-full mx-4"
          >
            <h3 className="text-xl font-bold text-gray-900 mb-4">Provide Feedback</h3>
            <p className="text-sm text-gray-600 mb-4">
              Please explain why you are declining the solution. This will help the staff better address your concerns.
            </p>
            <textarea
              value={declineFeedback}
              onChange={(e) => setDeclineFeedback(e.target.value)}
              placeholder="Enter your feedback here..."
              className="w-full p-3 border border-gray-300 rounded-md focus:ring-2 focus:ring-[#F27528] focus:border-transparent min-h-[120px]"
              required
            />
            <div className="flex justify-end gap-3 mt-4">
              <button
                onClick={() => {
                  setShowFeedbackModal(false);
                  setDeclineFeedback('');
                }}
                className="px-4 py-2 text-sm font-medium text-gray-700 hover:bg-gray-100 rounded-md transition-colors"
              >
                Cancel
              </button>
              <button
                onClick={handleDeclineWithFeedback}
                disabled={!declineFeedback.trim()}
                className="px-4 py-2 text-sm font-medium text-white bg-red-600 hover:bg-red-700 rounded-md transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
              >
                Submit Feedback
              </button>
            </div>
          </motion.div>
        </div>
      )}

      {/* Add Delete Modal */}
      {showDeleteModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 max-w-md w-full mx-4">
            <div className="flex items-center gap-3 mb-4">
              <AlertCircle className="text-red-500 w-6 h-6" />
              <h3 className="text-xl font-semibold text-gray-900">Delete Complaint</h3>
            </div>
            
            <p className="text-gray-600 mb-6">
              Are you sure you want to delete this complaint? This action cannot be undone.
              <br />
              <span className="font-medium">Token: {complaintToDelete?.token}</span>
            </p>

            <div className="flex justify-end gap-3">
              <button
                onClick={() => {
                  setShowDeleteModal(false);
                  setComplaintToDelete(null);
                }}
                className="px-4 py-2 text-gray-600 hover:text-gray-800 font-medium rounded-lg"
                disabled={isDeleting}
              >
                Cancel
              </button>
              <button
                onClick={handleDeleteConfirm}
                disabled={isDeleting}
                className="px-4 py-2 bg-red-500 hover:bg-red-600 text-white font-medium rounded-lg flex items-center gap-2"
              >
                {isDeleting ? 'Deleting...' : 'Delete'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Add Delete Button to Selected Complaint */}
      {selectedComplaint && (
        <div className="mt-4 flex justify-end">
          <button
            onClick={() => handleDeleteClick(selectedComplaint)}
            className="flex items-center gap-2 px-4 py-2 text-red-500 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors"
          >
            <Trash2 className="w-4 h-4" />
            Delete Complaint
          </button>
        </div>
      )}
    </div>
  );
};

export default TrackComplaint; 